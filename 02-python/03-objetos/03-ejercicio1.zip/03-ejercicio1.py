nombre = "Juan"
apellidos = "Perez Perez"
edad = "31"
email = "juan@perezperez.es"
telefono = "555 12 34 56"
casado = False
hijos = False
amigos = { "Pepe", "Antonio", "Jose" }
peliculas = { 'peli1': 'Blade Runner', 'peli2': 'Star Wars', 'peli3': 'Up!' }

print(nombre, apellidos)
print(edad)
print(email)
print(telefono)
print('casado: ', casado)
print('hijos: ', hijos)
print('amigos: ', amigos)
print('peliculas: ', peliculas)
